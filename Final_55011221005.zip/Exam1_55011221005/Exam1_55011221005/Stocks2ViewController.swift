//
//  Stocks2ViewController.swift
//  Exam1_55011221005
//
//  Created by student on 12/17/14.
//  Copyright (c) 2014 Pramot. All rights reserved.
//

import UIKit

class Stocks2ViewController: UIViewController {
    
    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var price: UITextField!
    
    
    @IBAction func save(sender: AnyObject) {
        
        
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }



}
