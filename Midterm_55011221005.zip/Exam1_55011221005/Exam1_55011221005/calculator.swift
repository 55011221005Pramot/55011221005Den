//
//  calculator.swift
//  Exam1_55011221005
//
//  Created by Student on 10/10/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import Foundation
class calculator {
    
    var volume:Double
    var price:Double
    var sum:Double{
    get{  return    }
    }
    
    init(volume:Double,price:Double){
        self.volume = volume
        self.price = price
    }
    
}