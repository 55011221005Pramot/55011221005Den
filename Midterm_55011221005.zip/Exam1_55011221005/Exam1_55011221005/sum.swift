//
//  sum.swift
//  Exam1_55011221005
//
//  Created by Student on 10/10/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import Foundation
class sum{
    
    var volume: Double
    var price: Double
    var sum :Double
        
        
    init(volume:Double,price:Double, sum:Double){
            self.volume = volume
            self.price = price
            self.sum  = sum
     }
    func cal(volume:String,Price:String){
       
    }
    

}